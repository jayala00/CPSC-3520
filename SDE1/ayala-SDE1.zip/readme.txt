Archive Contents:
1.) readme.txt
    - This file explains what every archived file does
2.) which_shape.pro
    - Contains all the required predicates
3.) sde1.log
    - Shows 3 test cases that aren't in the write up, for each predicate 

Pledge:
On my honor I have neither given nor received aid on this
exam
SIGN: Jonathan Ayala
